// stdio.h exposes this library
#include <inc/types.h>
#include <inc/stdio.h>
#include <inc/stdarg.h>
#include <inc/lib.h>

// global variables
static uint32_t *window_frame_buffer = (uint32_t*) (UTEMP + PGSIZE);
static char *font_buffer = (char*) UTEMP;
static int window_width = 1024;
static int window_height = 768;
static int bytes_per_pixel = 4;
static int window_initialized = 0;

// needed by cprintf
int window_set_pixel(uint32_t x, uint32_t y, uint32_t color) {
  if (window_initialized == 0) return -1;
  // In 32 BPP each pixel is 4 bytes and easiest accessed as
  // longwords (32 bits). The fourth byte is ignored. The colour
  // components is layout like in 24 BPP. Accessing pixels as
  // longwords the colour should be defined as 0x00RRGGBB.
  if ((x < window_width) && (y < window_height)) {
    window_frame_buffer[y * window_width + x] = color;
    return 0;
  }
  return -1;
}

char* get_font_buffer(void) {
  return font_buffer;
}

int init_window_buffer(int width, int height) {
  int pageidx, r, x, y;

  int fontfilesize = 3056;
  int rfd;
  int data;

  if (window_initialized == 0) {

    // set the global variables
    window_width = width;
    window_height = height;

    // allocate the memory for fonts
    if ((r = sys_page_alloc(sys_getenvid(), font_buffer, PTE_P | PTE_U | PTE_W)) < 0) {
      panic("testfont: %e", r);
    }

    // allocate the memory for the frame buffer
    for (pageidx = 0; pageidx < (1024 * 768) * 4; pageidx += PGSIZE) {
      if ((r = sys_page_alloc(sys_getenvid(), UTEMP + PGSIZE + pageidx, PTE_P | PTE_U | PTE_W)) < 0) {
        panic("testfont: %e", r);
      }
    }

    // set this before initializing pretty bg colors
    window_initialized = 1;

    // initialize the frame buffer to a color
    for (x = 0; x < width; x++) {
      for (y = 0; y < height; y++) {
        window_set_pixel(x, y, 0x00000000);
      }
    }

    // read in the font buffer
    if ((rfd = open("/font", O_RDONLY)) < 0) panic("open /font: %e", rfd);
    while ((data = read(rfd, font_buffer, fontfilesize)) > 0) {
      //sys_cputs(font_buffer, data); // just prints to console?
    }
    if (data < 0) panic("read /font: %e", data);
    close(rfd);

  }
  return 0;
}

int is_window_buffer_initialized(void) {
  return window_initialized;
}

uint32_t* get_window_buffer(void) {
  return window_frame_buffer;
}

int get_window_height(void) {
  return window_height;
}

int get_window_width(void) {
  return window_width;
}


/*
int screenwidth = 1024;
int screenheight = 768;

int screencolor = 0x000000;
int fontwidth = 8;
int fontheight = 16;
int fontcolor = 0xFFFFFF;

static void set_pixel(uint32_t x, uint32_t y, uint32_t color);

void umain(void) {
  char *font_buffer = (char*) UTEMP;
  int fontfilesize = 3056;
  int frameidx, fontidx, pageidx;
  char fontbyte;
  int rowidx, colidx;
  int r;
  int rfd;
  int data;

  // Initialize the buffers
  // don't use malloc, because it may cross a page boundary and page fault
  if ((r = sys_page_alloc(sys_getenvid(), font_buffer, PTE_P | PTE_U | PTE_W)) < 0) {
    panic("testfont: %e", r);
  }
  for (pageidx = 0; pageidx < (screenwidth * screenheight) * 4; pageidx += PGSIZE) {
    //cprintf("%08x\n", pageidx);
    if ((r = sys_page_alloc(sys_getenvid(), UTEMP + PGSIZE + pageidx, PTE_P | PTE_U | PTE_W)) < 0) {
      panic("testfont: %e", r);
    }
  }

  // read in the font buffer
  if ((rfd = open("/font", O_RDONLY)) < 0) panic("open /font: %e", rfd);
  while ((data = read(rfd, font_buffer, fontfilesize)) > 0) {
    //sys_cputs(font_buffer, data); // just prints to console?
  }
  // Debug
  //for (fontidx = 0; fontidx < 3056; fontidx++) {
  //  cprintf("font[%d] %02x\n", fontidx, font_buffer[fontidx]);
  //}
  if (data < 0) panic("read /font: %e", data);
  close(rfd);

}

*/

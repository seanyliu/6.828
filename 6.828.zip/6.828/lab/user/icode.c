#include <inc/lib.h>

void set_background(void);

void
umain(void)
{
	int fd, n, r;
	char buf[512+1];

	cprintf("icode startup\n");

        //set_background();

	cprintf("icode: open /motd\n");
	if ((fd = open("/motd", O_RDONLY)) < 0)
		panic("icode: open /motd: %e", fd);

	cprintf("icode: read /motd\n");
	while ((n = read(fd, buf, sizeof buf-1)) > 0)
		sys_cputs(buf, n);

	cprintf("icode: close /motd\n");
	close(fd);

	cprintf("icode: spawn /init\n");
	if ((r = spawnl("/init", "init", "initarg1", "initarg2", (char*)0)) < 0)
		panic("icode: spawn /init: %e", r);

	cprintf("icode: exiting\n");
}
/*
void
set_background(void)
{
	int fd;
	char buf[512];
	int i, r;
	char *temp_buffer = (char*)UTEMP;
	
	for (i = 0; i < 1024*768*4; i += PGSIZE) { // 4 bytes per pixel
	  if ((r = sys_page_alloc(sys_getenvid(), UTEMP + i, PTE_P | PTE_U | PTE_W)) < 0) {
	    panic("setbackground: %e", r);
	  }
	}

	if ((fd = open("/starcraft", O_RDWR)) < 0)
		panic("open /starcraft: %e", fd);

	// read past first 54 bytes of file (header)
	read(fd, buf, 54);
	// 24-bit bitmap needs to be converted to our 32-bit frame buffer
	// bitmap starts at bottom left, frame buffer starts at top left
	// we need to remap the bytes for each pixel to the frame buffer
	// pixel mapping: a*1024*3+b*3+c -> (767-a)*1024*4+b*4+(3-c)
	// c = rem(i,3)
	// b = (rem(i,1024*3)-c)/3
	// a = (i-b*3-c)/(1024*3)
	int a, b, c;
	for (i = 0; i < 1024*768*3; i++) { // 3 bytes per pixel
	  c = i % 3;
	  b = (i % (1024*3) - c)/3;
	  a = (i-b*3-c)/(1024*3);
	  read(fd, temp_buffer + (767-a)*1024*4+b*4+c, 1);
	}

	close(fd);
	sys_draw_buffer(0, 0, 1024, 768, (uint32_t*)temp_buffer);
}
*/

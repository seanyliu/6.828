#ifndef LWIP_ARCH_PERF_H
#define LWIP_ARCH_PERF_H

#define PERF_START
#define PERF_STOP(x)

#endif

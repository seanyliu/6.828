#include <kern/pmap.h> // boot_pgdir, pgdir_walk
#include <inc/x86.h>   // need for outw
#include <kern/vga.h>
#include <kern/env.h>
#include <inc/string.h>

/*
This code is a JOS implementation of http://wiki.osdev.org/Bochs_VBE_extensions
*/

// Declare the static methods (only visible to this file)
static void vga_write_register(uint16_t index_value, uint16_t data_value);
static uint16_t vga_read_register(uint16_t index_value);
static int vga_is_available(void);

// Declare some global variables
static uint32_t vga_width;
static uint32_t vga_height;
static uint32_t vga_bg = 0x000000;
uint32_t *frame_buffer;
static int current_pos = 0;

static int font_max_cols;
static int font_max_rows;
static int font_max_chars;
static int font_color = 0xFFFFFF;

static int vga_char_pos = 0;

uint32_t vga_get_height(void) {
  return vga_height;
}

uint32_t vga_get_width(void) {
  return vga_width;
}

void set_pixel(uint32_t x, uint32_t y, uint32_t color) {
  // In 32 BPP each pixel is 4 bytes and easiest accessed as
  // longwords (32 bits). The fourth byte is ignored. The colour
  // components is layout like in 24 BPP. Accessing pixels as
  // longwords the colour should be defined as 0x00RRGGBB.
  if ((y < vga_height) && (x < vga_width)) {
    frame_buffer[y * vga_width + x] = color;
  }
}

void vga_init(void) {

  int rowidx, colidx = 0;

  // check if the latest version of vga is present
  // do NOT return, because then you fail to map the memory
  // and will cause problems since other code assumes it's
  // been mapped.
  /*
  if (!vga_is_available()) {
    return 0;
  }
  */

  // set up the video mode
  vga_width = VBE_DISPI_MAX_XRES;
  vga_height = VBE_DISPI_MAX_YRES;
  font_max_cols = vga_width / FONT_WIDTH;
  font_max_rows = vga_height / FONT_HEIGHT;
  font_max_chars = font_max_cols * font_max_rows;
  vga_write_register(VBE_DISPI_INDEX_ENABLE, VBE_DISPI_DISABLED);
  vga_write_register(VBE_DISPI_INDEX_XRES, 1024);
  vga_write_register(VBE_DISPI_INDEX_YRES, 768);
  vga_write_register(VBE_DISPI_INDEX_BPP, 32);
  vga_write_register(VBE_DISPI_INDEX_ENABLE, VBE_DISPI_ENABLED | VBE_DISPI_LFB_ENABLED | 0);
  // | 0 just for seanyliu to remember that this clears the video memory

  // Initialize our access to the linear frame buffer.
  // When using a linear frame buffer, the BGA exposes all of the graphics
  // memory in a linear fashion. The location is fixed at 0xE0000000 (phys addr).
  // Note that the physical addresses are mapped at KERNBASE.
  frame_buffer = (uint32_t *)(VBE_DISPI_LFB_PHYSADDR + KERNBASE);

  // initialize some pretty pixels on the screen
  for (rowidx = 0; rowidx < vga_height; rowidx++) {
    for (colidx = 0; colidx < vga_width; colidx++) {
      set_pixel(colidx, rowidx, vga_bg);
    }
  }
}


/**
 * Model this after cga_putc
 */
void vga_putc(int c) {
  // model after cga_putc
  int fontidx;
  char fontbyte;
  int rowidx;
  int colidx;
  int fontnum;
  int color;

  // ========================
  // Step 1: calculate the index of the character, should just be c - 32
  // if no attribute given, then use space

  switch (c & 0xff) {
    case '\n':
      vga_char_pos += font_max_cols - (vga_char_pos % font_max_cols);
      break;
    case '\r':
    case '\t':
      break;
    case '\b':
      vga_char_pos--;
      break;
  }
  fontidx = c - 32;

  if ((c > 126) || (c < 32)) {
    fontidx = 0;
  }

  // ========================
  // Step 2: Draw the character
  for (rowidx = 0; rowidx < FONT_HEIGHT; rowidx++) {
    // read out one row of font
    fontnum = (fontidx * 16) + rowidx;
    fontbyte = _binary_obj_fs_font_start[fontnum];
    for (colidx = 0; colidx < FONT_WIDTH; colidx++) {
      if ((fontbyte & (0x80 >> colidx)) != 0) {
        color = font_color;
      } else {
        color = vga_bg;
      }
      set_pixel(colidx + ((vga_char_pos % font_max_cols) * FONT_WIDTH), rowidx + ((vga_char_pos / font_max_cols) * FONT_HEIGHT), color);
    }
  }
  if ((c != '\b') && (c != '\n')) vga_char_pos++;

  // =======================
  // Scroll the page
  if (vga_char_pos > (font_max_chars - 1)) {
    // frame_buffer is a uint32_t, therefore * 1
    memmove(frame_buffer, frame_buffer + ((vga_width * FONT_HEIGHT)*1), (vga_width * vga_height - (vga_width * FONT_HEIGHT)) * 4);
    for (rowidx = 0; rowidx < FONT_HEIGHT; rowidx++) {
      for (colidx = 0; colidx < vga_width; colidx++) {
        set_pixel(colidx, vga_height - FONT_HEIGHT + rowidx, vga_bg);
      }
    }
    vga_char_pos -= font_max_cols;
  }
}

void vga_map_framebuffer(void) {
  // do stuff similar to boot_map_segment.
  // i.e. map an (arbitrary) virtual address to the frame buffer phys addr.
  int pidx;
  pte_t *pgtbl_entry;
  for (pidx = 0; pidx < (vga_width * vga_height * VBE_DISPI_BPP_32 / 8); pidx += PGSIZE) {
    pgtbl_entry = pgdir_walk(boot_pgdir, (void *)(VBE_DISPI_LFB_VADDR + pidx), 1);
    *pgtbl_entry = (VBE_DISPI_LFB_PHYSADDR + pidx) | PTE_W | PTE_P | PTE_SHARE;
  }
  frame_buffer = (uint32_t *)VBE_DISPI_LFB_VADDR;
}

static void vga_write_register(uint16_t index_value, uint16_t data_value) {
  outw(VBE_DISPI_IOPORT_INDEX, index_value);
  outw(VBE_DISPI_IOPORT_DATA, data_value);
}

static uint16_t vga_read_register(uint16_t index_value) {
  outw(VBE_DISPI_IOPORT_INDEX, index_value);
  return inw(VBE_DISPI_IOPORT_DATA);
}

static int vga_is_available(void) {
  // check if we have the latest Bochs
  return (vga_read_register(VBE_DISPI_INDEX_ID) == VBE_DISPI_ID4);
}

// draw a width by height rectangle with top corner at (x, y)
// colors for each pixel are specified by an array
// at buffer_addr, with a format similar to frame_buffer
void vga_draw_buffer(int x, int y, int width, int height, uint32_t *buffer_addr) {
  int row, col;
  for (row = y; row < y + height; row++) {
    for (col = x; col < x + width; col++) {
      set_pixel(col, row, buffer_addr[(row - y) * width + (col - x)]);
    }
  }
}

#ifndef JOS_KERN_E100_H
#define JOS_KERN_E100_H

#include <kern/pci.h>
#include <kern/pcireg.h>

#define E100_VENDOR_ID 0x8086
#define E100_PRODUCT_ID 0x1209

#define CBL_SIZE 128
#define RFA_SIZE 128
#define PACKET_DATA_SIZE 1518

#define STATUS_C 0x8000
#define COMMAND_S 0x4000

int pci_e100_attach(struct pci_func *pcif);
void e100_reset();
void init_cbl();
void init_rfa();
void e100_send_packet(char *packet, int size);
int e100_receive_packet(char *packet, int *size);
int e100_map_receive_buffers(char *first_buffer);
int e100_receive_packet_zero_copy();
void start_cu(int tcb_to_send);
void resume_cu();
void start_ru();

struct cb {
  volatile uint16_t status;
  uint16_t cmd;
  uint32_t link;
};

struct tbd {
  uint32_t buffer_address;
  uint32_t buffer_size;
};

struct tcb {
  struct cb header;
  uint32_t array_addr;
  uint16_t byte_count;
  uint8_t thrs;
  uint8_t tbd_count;
  struct tbd tbd1;
  struct tbd tbd2;
  //char data[PACKET_DATA_SIZE];
};

struct rfd_header {
  volatile uint16_t status;
  uint16_t cmd;
  uint32_t link;
};

struct rfd {
  struct rfd_header header;
  uint32_t reserved;
  uint16_t actual_count;
  uint16_t size;
  //char data[PACKET_DATA_SIZE];
};

struct rbd {
  uint32_t count;
  uint32_t link;
  uint32_t buffer_address;
  uint32_t size;
};

#endif	// JOS_KERN_E100_H

// Draws a white square to the screen with the draw_buffer syscall
#include <inc/lib.h>

uint32_t *frame_buffer = (uint32_t*) (UTEMP + PGSIZE);
int screenwidth = 1024;
int screenheight = 768;
int screencolor = 0x000000;
int fontwidth = 8;
int fontheight = 16;
int fontcolor = 0xFFFFFF;

static void set_pixel(uint32_t x, uint32_t y, uint32_t color);
static void set_pixel(uint32_t x, uint32_t y, uint32_t color) {
  // In 32 BPP each pixel is 4 bytes and easiest accessed as
  // longwords (32 bits). The fourth byte is ignored. The colour
  // components is layout like in 24 BPP. Accessing pixels as
  // longwords the colour should be defined as 0x00RRGGBB.
  frame_buffer[y * screenwidth + x] = color;
}

void umain(void) {
  char *font_buffer = (char*) UTEMP;
  int fontfilesize = 3056;
  int frameidx, fontidx, pageidx;
  char fontbyte;
  int rowidx, colidx;
  int r;
  int rfd;
  int data;

  // Initialize the buffers
  // don't use malloc, because it may cross a page boundary and page fault
  if ((r = sys_page_alloc(sys_getenvid(), font_buffer, PTE_P | PTE_U | PTE_W)) < 0) {
    panic("testfont: %e", r);
  }
  for (pageidx = 0; pageidx < (screenwidth * screenheight) * 4; pageidx += PGSIZE) {
    //cprintf("%08x\n", pageidx);
    if ((r = sys_page_alloc(sys_getenvid(), UTEMP + PGSIZE + pageidx, PTE_P | PTE_U | PTE_W)) < 0) {
      panic("testfont: %e", r);
    }
  }

  // read in the font buffer
  if ((rfd = open("/font", O_RDONLY)) < 0) panic("open /font: %e", rfd);
  while ((data = read(rfd, font_buffer, fontfilesize)) > 0) {
    //sys_cputs(font_buffer, data); // just prints to console?
  }
  // Debug
  //for (fontidx = 0; fontidx < 3056; fontidx++) {
  //  cprintf("font[%d] %02x\n", fontidx, font_buffer[fontidx]);
  //}
  if (data < 0) panic("read /font: %e", data);
  close(rfd);

  // set first side_len^2 pixels in the buffer to white
  for (frameidx = 0; frameidx < 1024*768; frameidx++) {
    frame_buffer[frameidx] = screencolor;
  }

  for (fontidx = 0; fontidx < 1; fontidx++) {
    for (rowidx = 0; rowidx < fontheight; rowidx++) {
      // read out one row of font
      fontbyte = font_buffer[(1 * 16) + rowidx];
      //cprintf("font: %08x\n", fontbyte);
      //cprintf("%08x\n", fontbyte);
      for (colidx = 0; colidx < fontwidth; colidx++) {
        //cprintf("mask:    %08x\n", (0x80 >> colidx));
        //cprintf("overlap: %08x\n", fontbyte & (0x80 >> colidx));
        if ((fontbyte & (0x80 >> colidx)) != 0) {
          //cprintf("SET\n");
          set_pixel(colidx, rowidx, fontcolor);
        }
      }
    }
  }

  sys_draw_buffer(0, 0, 1024, 768, frame_buffer);
}

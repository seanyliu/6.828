#include <kern/wmgr.h>
#include <kern/vga.h>

// Declare global variables
struct window_node *head;
struct window_node windows[MAX_WINDOWS];

// Mouse location
int mouse_x;
int mouse_y;
int mouse_down_x;
int mouse_down_y;

// Window loc
int win_x;
int win_y;

struct window_node *mouse_down_window;

uint8_t *bg_bmp;

// Declare functions
uint32_t extract_bg_pixel(uint32_t x, uint32_t y);
void paint_rectangle(uint32_t x, uint32_t y, uint32_t width, uint32_t height, int repaint_mouse);
void paint_mouse(uint32_t x, uint32_t y);

void
wmgr_init(void) {
  mouse_x = 512;
  mouse_y = 384;
  win_x = 0;
  win_y = 0;
  bg_bmp = (uint8_t *)_binary_obj_fs_starcraft_start;
  paint_rectangle(0, 0, vga_get_width(), vga_get_height(), 1);
}

void set_bg(int bgselect) {
  if (bgselect == 0) {
    bg_bmp = (uint8_t *)_binary_obj_fs_starcraft_start;
  } else if (bgselect == 1) {
    bg_bmp = (uint8_t *)_binary_obj_fs_bebop_start;
  } else if (bgselect == 2) {
    bg_bmp = (uint8_t *)_binary_obj_fs_win7_start;
  }
  paint_rectangle(0, 0, vga_get_width(), vga_get_height(), 1);
}

uint32_t
extract_bg_pixel(uint32_t x, uint32_t y) {
  int bg_width = 1024;
  int bg_height = 768;

  int bg_col = x;
  int bg_row = bg_height - y - 1;

  // 24-bit bitmap needs to be converted to our 32-bit frame buffer
  // bitmap starts at bottom left, frame buffer starts at top left
  uint32_t blue = 0xFF & bg_bmp[54 + ( bg_col + bg_row * bg_width )* 3];
  uint32_t green = 0xFF & bg_bmp[54 + ( bg_col + bg_row * bg_width )* 3 + 1];
  uint32_t red = 0xFF & bg_bmp[54 + ( bg_col + bg_row * bg_width )* 3 + 2];

  return (red << 16) + (green << 8) + blue;
}

// returns 0 on success, -1 if location doesn't correspond to a window
int
window_at_location(uint32_t x, uint32_t y, struct window_node **window_node_store) {
  if (!head) {
    return -1;
  }
  struct window_node *temp = head;
  
  // loop through windows and check which one we should get pixel from
  
  while(temp != 0) {
    // check if the pixel is in the window's rectangle
    if (y >= temp->window.y && y < temp->window.y + temp->window.height &&
	x >= temp->window.x && x < temp->window.x + temp->window.width) {
      *window_node_store = temp;
      return 0;
    }

    temp = temp->next;
  }
  return -1;
}

int
is_title_bar_at_location(uint32_t x, uint32_t y, struct window_node *window_node) {
  if (y >= window_node->window.y && y < window_node->window.y + TITLE_BAR_HEIGHT &&
	x >= window_node->window.x && x < window_node->window.x + window_node->window.width) {
    return 1;
  }

  return 0;
}

int
is_in_close_box(uint32_t x, uint32_t y, struct window_node *window_node) {
  if (y < window_node->window.y + TITLE_BAR_HEIGHT ||
      y >= window_node->window.y + window_node->window.height - BORDER_WIDTH ||
      x < window_node->window.x + BORDER_WIDTH ||
      x >= window_node->window.x + window_node->window.width - BORDER_WIDTH) {
    
    // check if it's in the close box
    int close_box_len = TITLE_BAR_HEIGHT - 4;
    if (y > window_node->window.y + 2 && y < window_node->window.y+TITLE_BAR_HEIGHT-2 &&
	x > window_node->window.x + window_node->window.width - BORDER_WIDTH - close_box_len - 2 &&
	x < window_node->window.x + window_node->window.width - BORDER_WIDTH - 2)
      return 1;
      
  }

  return 0;
}

void
paint_rectangle(uint32_t x, uint32_t y, uint32_t width, uint32_t height, int repaint_mouse) {
  int row, col;
  struct window_node *temp;
  uint32_t buf_pix;
  struct Page *buffer_page;
  uint32_t *buffer;
  struct Env *env;
  for (row = y; row < y + height; row++) {
    for (col = x; col < x + width; col++) {
      if (window_at_location(col, row, &temp) == 0) {
	// check if it's in the header/border
	if (row < temp->window.y + TITLE_BAR_HEIGHT ||
	    row >= temp->window.y + temp->window.height - BORDER_WIDTH ||
	    col < temp->window.x + BORDER_WIDTH ||
	    col >= temp->window.x + temp->window.width - BORDER_WIDTH) {
	  // check if it's in the close box
	  int close_box_len = TITLE_BAR_HEIGHT - 4;
	  if (row > temp->window.y + 2 && row < temp->window.y+TITLE_BAR_HEIGHT-2 &&
	      col > temp->window.x + temp->window.width - BORDER_WIDTH - close_box_len - 2 &&
	      col < temp->window.x + temp->window.width - BORDER_WIDTH - 2)
	    set_pixel(col,row,CLOSE_BOX_COLOR);
	  else
	    set_pixel(col, row, BORDER_COLOR);
	} else {
	  // otherwise, paint it from the buffer
          buf_pix = temp->window.frame_buffer_address + 4 *
	            ((row - temp->window.y - TITLE_BAR_HEIGHT) *
		     (temp->window.width - 2*BORDER_WIDTH) +
		     (col - temp->window.x - BORDER_WIDTH));
	  // in case a process finished running
	  if (envid2env(temp->envid, &env, 0) < 0) {
	    close_window(temp->envid);
	    return;
	  }
          buffer_page = page_lookup(env->env_pgdir, (void *)buf_pix, NULL);
          buffer = page2kva(buffer_page);
	  set_pixel(col, row, buffer[buf_pix/4 - ROUNDDOWN(buf_pix/4, PGSIZE/4)]);
	}
      } else {
	// draw pixel from background
	set_pixel(col, row, extract_bg_pixel(col, row));
      }
    }
  }
  if (repaint_mouse) {
    // repaint the mouse
    paint_mouse(mouse_x, mouse_y);
  }
}

void
paint_mouse(uint32_t x, uint32_t y) {
  set_pixel(x, y-1, BLACK);
  set_pixel(x, y, BLACK);

  int i,j;
  for (i = 0; i < MOUSE_SIZE-3; i++) {
    set_pixel(x-i/2-1, y+i+1, BLACK);
    for (j = x-i/2; j <= x+i/2; j++) {
      set_pixel(j, y+i+1, WHITE);
    }
    set_pixel(x+i/2+1, y+i+1, BLACK);
  }

  set_pixel(x-i/2-1, y+i+1, BLACK);
  for (j = x-i/2; j <= x+i/2; j++) {
    set_pixel(j, y+i+1, BLACK);
  }
  set_pixel(x+i/2+1, y+i+1, BLACK);
}

void
move_window_to_front(int envid)
{
  int window_found = 0;

  if (!head || head->envid == envid) {
    return;
  }

  // remove window from linked list
  struct window_node *temp = head->next;
  while (temp != 0) {
    if (temp->envid != envid) {
      temp = temp->next;
      continue;
    }

    window_found = 1;
    break;
  }

  if (!window_found)
    return;

  temp->prev->next = temp->next;
  if (temp->next != 0)
    temp->next->prev = temp->prev;

  // put window in the beginning of linked list
  temp->next = head;
  temp->prev = 0;
  head->prev = temp;
  head = temp;

  // redraw window
  paint_rectangle(head->window.x, head->window.y, head->window.width, head->window.height, 1);
}

int
open_window(int envid, int width, int height, uint32_t *buf)
{
  int i,r;
  int window_found = 0;

  struct window_node *new_node = &windows[0];

  for (i=0;i<MAX_WINDOWS;i++) {
    if (windows[i].envid == 0) {
      new_node = &windows[i];
      window_found = 1;
    }
  }

  if (!window_found)
    return -1; // no more windows can be allocated

  win_x = (win_x+50)%1000;
  win_y = (win_y+50)%700;

  new_node->window.x = win_x;
  new_node->window.y = win_y;
  new_node->window.height = height + TITLE_BAR_HEIGHT + BORDER_WIDTH;
  new_node->window.width = width + 2*BORDER_WIDTH;
  new_node->window.frame_buffer_address = (uint32_t) buf;

  new_node->envid = envid;
  new_node->prev = 0;
  new_node->next = 0;
  if (head) {
    new_node->next = head;
    head->prev = new_node;
  }
  head = new_node;

  // repaint the window rectangle
  paint_rectangle(head->window.x, head->window.y, head->window.width, head->window.height, 1);
  return 0;
}

int
close_window(int envid) 
{
  int window_found = 0;

  if (!head) {
    return -1;
  }

  // remove window from linked list
  struct window_node *temp = head;
  while (temp != 0) {
    if (temp->envid != envid) {
      temp = temp->next;
      continue;
    }

    window_found = 1;
    
    if (temp == head) {
      head = temp->next;
    } else {
      temp->prev->next = temp->next;
    }

    if (temp->next != 0) {
      temp->next->prev = temp->prev;
    }

    // kill the env that's running the window if it isn't already dead
/*
    struct Env *env;
    if (envid2env(temp->envid, &env, 0) >= 0) {    
      env_destroy(env);
    }
*/

    break;
  }
  
  // redraw if necessary
  if (window_found){
    paint_rectangle(temp->window.x, temp->window.y, temp->window.width, temp->window.height, 1);

    // clear fields so new windows can be allocated
    temp->envid = 0;
    temp->next = 0;
    temp->prev = 0;
  }

  return 0;
}

int
update_window(int envid)
{
  int window_found = 0;

  // find window in linked list 
  struct window_node *temp = head;
  while (temp != 0) {
    if (temp->envid != envid) {
      temp = temp->next;
      continue;
    }
    
    window_found = 1;
    break;
  }

  // redraw if necessary
  if (window_found) {
    paint_rectangle(temp->window.x, temp->window.y, temp->window.width, temp->window.height, 1);
  }
   
  return 0;
}

void 
mouse_move(int x, int y) 
{
  int rec_x = mouse_x - MOUSE_SIZE/2;
  if (rec_x < 0) {
    rec_x = 0;
  }
  int rec_y = mouse_y - 1;
  if (rec_y < 0) {
    rec_y = 0;
  }

  paint_rectangle(rec_x, rec_y, MOUSE_SIZE, MOUSE_SIZE, 0);
  paint_mouse(x, y);

  mouse_x = x;
  mouse_y = y;
}

void
move_window_by(struct window_node *window_node, int dx, int dy)
{
  int prev_x,prev_y;
  prev_x = window_node->window.x;
  prev_y = window_node->window.y;
  
  window_node->window.x += dx;
  if ((int)(window_node->window.x) < 0) {
    window_node->window.x = 0;
  }

  window_node->window.y += dy;
  if ((int)(window_node->window.y) < 0) {
    window_node->window.y = 0;
  }
  
  paint_rectangle(prev_x, prev_y, window_node->window.width, window_node->window.height, 1);  
  paint_rectangle(window_node->window.x, window_node->window.y, window_node->window.width, window_node->window.height, 1);  

  mouse_down_x += dx;
  mouse_down_y += dy;
}

void 
mouse_update(int x, int y, int left_pressed, int right_pressed, int middle_pressed)
{
  if (left_pressed) {
    struct window_node *temp;
    if (window_at_location(x, y, &temp) == 0) {
      // move window to front
      move_window_to_front(temp->envid);
    
      if (mouse_down_x == -1) {
	mouse_down_x = x;
	mouse_down_y = y;
	mouse_down_window = temp;
      }
      
      if (mouse_down_x != -1 && is_title_bar_at_location(mouse_down_x,mouse_down_y,mouse_down_window)) {
	int dx, dy;
	dx = x - mouse_down_x;
	dy = y - mouse_down_y;
	if (dx!=0 || dy!=0) {
	  move_window_by(mouse_down_window,dx,dy);
	}
      }

    }
     
  } else {
    if (mouse_down_x == x && mouse_down_y == y) {
      struct window_node *temp;
      if (window_at_location(x, y, &temp) == 0) {
	if (is_in_close_box(x, y, temp)) {
	  close_window(temp->envid);
	}
      }
    }

    mouse_down_x = -1;
    mouse_down_y = -1;
    mouse_down_window = (struct window_node *)-1;
  }

  if (middle_pressed) {
    // close window
    struct window_node *temp;
    if (window_at_location(x, y, &temp) == 0) {
      close_window(temp->envid);
    }    
  }

  mouse_move(x,y);
}

#include <inc/stdio.h>
#include <inc/lib.h>


int x, y;

void
startmouse() 
{
  
  int i, right, left, middle;
  
  struct mouse_packet *packet = (struct mouse_packet*)(UTEMP + PGSIZE*4);
  sys_page_alloc(sys_getenvid(), packet, PTE_P|PTE_U|PTE_W);

  while (1) {  
    right = left = middle = 0;

    sys_get_mouse_packet(packet);

    if (packet->info == 0) {
      sys_yield();
      continue;
    }

    if (packet->info & 0x2) {
      right = 1;
    }

    if (packet->info & 0x1) {
      left = 1;
    }

    if (packet->info & 0x4) {
      middle = 1;
    }


    if (packet->info & 0x10) {
      x += ((~(packet->x) & 0xFF)*-1) - 1;
    } else {
      x += (packet->x);
    }

    if (x < 0) {
      x = 0;
    } else if (x >= 1024) {
      x = 1023;
    }

    if (packet->info & 0x20) {
      y -= ((~(packet->y) & 0xFF)*-1) -1;
    } else {
      y -= (packet->y);
    }

    if (y < 0) {
      y = 0;
    } else if (y >= 768) {
      y = 767;
    }
    
    sys_mouse_update(x,y,left,right,middle);

    sys_yield();
  }

}



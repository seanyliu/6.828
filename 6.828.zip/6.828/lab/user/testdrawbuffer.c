// Draws a white square to the screen with the draw_buffer syscall
#include <inc/lib.h>
#include <lib/mouse.c>

void
umain(void)
{
  int i, r, x, y, pageidx, frameidx;
  int side_len = 200;
  init_window_buffer(side_len, side_len);
  sys_open_window(sys_getenvid(), side_len, side_len, get_window_buffer());
  cprintf("hello");

  //sys_draw_buffer(0,0,side_len, side_len, get_window_buffer());
	/*
        int pageidx, i, r;
        int side_len = 200;
	uint32_t *temp_buffer = (uint32_t*)(UTEMP + PGSIZE);
	// allocate the memory for the frame buffer
	for (pageidx = 0; pageidx < (side_len * side_len)*4; pageidx += PGSIZE) {
	  if ((r = sys_page_alloc(sys_getenvid(), (void *)(UTEMP+PGSIZE + pageidx), PTE_P | PTE_U | PTE_W)) < 0) {
	    panic("testfont: %e", r);
	  }
	}
	for (i = 0; i < side_len*side_len; i++) {
	  temp_buffer[i] = 0x00FF9900;
        }


	sys_open_window(sys_getenvid(), side_len, side_len, temp_buffer);
	//	sys_draw_buffer(0,0,side_len, side_len, temp_buffer);
*/
	
/*
	for (i = 0; i < side_len*side_len; i++) {
	  temp_buffer[i] = 0x00FF99FF;
	}

	sys_open_window(40, 10,10,temp_buffer2);

	//sys_update_window(sys_getenvid());
	sys_update_window(sys_getenvid());
*/

	//sys_close_window(sys_getenvid());









  //int screenwidth = 1024;
  //int screenheight = 768;
	//uint32_t *temp_buffer = (uint32_t*)UTEMP;
  //uint32_t *frame_buffer = (uint32_t*) (UTEMP + PGSIZE);
 // char *font_buffer = (char*) UTEMP;
  // Initialize the buffers
  // don't use malloc, because it may cross a page boundary and page fault
/*
  if ((r = sys_page_alloc(sys_getenvid(), font_buffer, PTE_P | PTE_U | PTE_W)) < 0) {
    panic("testfont: %e", r);
  }
*/

/*
  for (pageidx = 0; pageidx < (screenwidth * screenheight) * 4; pageidx += PGSIZE) {
    //cprintf("%08x\n", pageidx);
    if ((r = sys_page_alloc(sys_getenvid(), UTEMP + PGSIZE + pageidx, PTE_P | PTE_U | PTE_W)) < 0) {
      panic("testfont: %e", r);
    }
  }
*/

/*
  // set first side_len^2 pixels in the buffer to white
  for (frameidx = 0; frameidx < 1024*768; frameidx++) {
    frame_buffer[frameidx] = 0x00FF9900;
  }
*/
//sys_open_window(sys_getenvid(), side_len, side_len, frame_buffer);

/*
>>>>>>> Stashed changes:user/testdrawbuffer.c
	if ((r = sys_page_alloc(sys_getenvid(), temp_buffer, PTE_P | PTE_U | PTE_W)) < 0) {
	  panic("testdrawbuffer: %e", r);
	}
*/
/*
	// set first side_len^2 pixels in the buffer to white
	for (i = 0; i < side_len*side_len; i++) {
	  temp_buffer[i] = 0x007799bb;
	}
*/



	// draw a side_len by side_len square with the side_len^2 white pixels
	//sys_draw_buffer(0, 0, 1024, 768, frame_buffer);

/*
	sys_open_window(sys_getenvid(), side_len, side_len, temp_buffer);
	
	uint32_t *temp_buffer2 = (uint32_t*)UTEMP+PGSIZE;
	sys_page_alloc(sys_getenvid(), temp_buffer2, PTE_P | PTE_U | PTE_W);
	for (i = 0; i < 10*10; i++) {
	  temp_buffer2[i] = 0x00FF99FF;
*/
/*
	uint32_t *temp_buffer;
init_window_buffer(side_len, side_len);
temp_buffer = get_window_buffer();
        for (x = 0; x < side_len; x++) {
          for (y = 0; y < side_len; y++) {
            window_set_pixel(x, y, 0x00FF9900);
          }
        }
*/
/*
	for (i = 0; i < side_len*side_len; i++) {
	  temp_buffer[i] = 0x00FF99FF;
	}

	sys_open_window(40, 10,10,temp_buffer2);

	//sys_update_window(sys_getenvid());
	sys_update_window(sys_getenvid());
*/

	//sys_close_window(sys_getenvid());
  while(1) {
    sys_yield();
  }
	
}

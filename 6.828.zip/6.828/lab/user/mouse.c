// Draws a white square to the screen with the draw_buffer syscall
#include <inc/lib.h>
#include <lib/mouse.c>

void
umain(void)
{
	startmouse();
}

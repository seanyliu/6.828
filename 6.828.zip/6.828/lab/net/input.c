#include "ns.h"
#include "kern/e100.h"

void
input(envid_t ns_envid)
{
	binaryname = "ns_input";

	// LAB 6: Your code here:
	// 	- read a packet from the device driver
	//	- send it to the network server
	int i, r, current_buffer;
	//	struct jif_pkt* packet = (struct jif_pkt*) UTEMP;
	for (i = 0; i < RFA_SIZE; i++) {
	  if ((r = sys_page_alloc(sys_getenvid(), UTEMP + (i*PGSIZE), PTE_P | PTE_U | PTE_W)) < 0) {
	    panic("input: %e", r);
	  }
	}
	sys_map_receive_buffers(UTEMP);
	current_buffer = 0;
	while(1) {
	  /*if ((r = sys_page_alloc(sys_getenvid(), UTEMP, PTE_P | PTE_U)) < 0) {
	    panic("input: %e", r);
	  }
	  if (sys_receive_packet(packet->jp_data, &packet->jp_len) == 0) {
	    ipc_send(ns_envid, NSREQ_INPUT, packet, PTE_P | PTE_U);
	  } else {
	    sys_yield();
	    }*/
	  struct jif_pkt* packet = (struct jif_pkt*) (UTEMP + (current_buffer * PGSIZE));
	  if ((r = sys_receive_packet_zero_copy(&packet->jp_len)) < 0) {
	    sys_yield();
	  } else {
	    ipc_send(ns_envid, NSREQ_INPUT, packet, PTE_P | PTE_U | PTE_W);
	    current_buffer = (current_buffer + 1) % RFA_SIZE;
	  }
	}
}

// LAB 6: Your driver code here

#include <kern/e100.h>
#include <kern/pci.h>
#include <kern/pcireg.h>
#include <inc/x86.h>
#include <inc/assert.h>
#include <inc/string.h>
#include <kern/pmap.h>
#include <kern/env.h>

uint32_t *e100_reg_base;
uint32_t *e100_reg_size;
uint8_t e100_irq_line;
uint32_t io_base;
struct tcb cbl[CBL_SIZE];
int prev_tcb_num;
struct rfd rfa[RFA_SIZE];
struct rbd rbds[RFA_SIZE];
int current_rfd_num;
int cu_started;
char *buffer_zero;

int
pci_e100_attach(struct pci_func *pcif) {
  pci_func_enable(pcif);
  e100_reg_base = pcif->reg_base;
  io_base = e100_reg_base[1];
  e100_reg_size = pcif->reg_size;
  e100_irq_line = pcif->irq_line;
  e100_reset();
  return 1;
}

void
e100_reset() {
  int i;
  outl(io_base + 0x8, 0x0000);
  for (i = 0; i < 8; i++) {
    inb(0x84);
  }
  init_cbl();
}

void
init_cbl() {
  int i;
  memset(cbl, 0, CBL_SIZE * sizeof(struct tcb));
  for(i = 0; i < CBL_SIZE; i++) {
    cbl[i].header.status = STATUS_C;
    cbl[i].header.link = PADDR(&cbl[(i+1)%CBL_SIZE]);
    //cbl[i].array_addr = 0xffffffff;
    cbl[i].array_addr = PADDR(&cbl[i].tbd1);
    cbl[i].thrs = 0xe0;
    cbl[i].tbd_count = 1;
  }
  prev_tcb_num = CBL_SIZE - 1;
  cu_started = 0;
}

void
init_rfa() {
  int i;
  memset(rfa, 0, RFA_SIZE * sizeof(struct rfd));
  memset(rbds, 0, RFA_SIZE * sizeof(struct rbd));
  for(i = 0; i < RFA_SIZE; i++) {
    rfa[i].header.link = PADDR(&rfa[(i+1)%RFA_SIZE]);
    //rfa[i].size = PACKET_DATA_SIZE;
    rfa[i].reserved = PADDR(&rbds[i]);
    rfa[i].header.cmd = 0x0008;
    rbds[i].link = PADDR(&rbds[(i+1)%RFA_SIZE]);
    rbds[i].size = PACKET_DATA_SIZE;
    struct Page *buffer_page = page_lookup(curenv->env_pgdir, buffer_zero + (i * PGSIZE), NULL);
    rbds[i].buffer_address = page2pa(buffer_page) + sizeof(int);
  }
  current_rfd_num = 0;
  start_ru();
}

void
e100_send_packet(char *packet, int size) {
  int current_tcb_num = (prev_tcb_num + 1) % CBL_SIZE;
  // if the tcb is available, then add the packet data to it
  if (cbl[current_tcb_num].header.status & STATUS_C) {
    cbl[current_tcb_num].header.status = 0;
    cbl[current_tcb_num].header.cmd = 0x400c; // set s bit, sf bit, and transmit cmd
    //cbl[current_tcb_num].byte_count = size;
    cbl[current_tcb_num].byte_count = 0;
    //memmove(cbl[current_tcb_num].data, packet, size);
    struct Page *packet_page = page_lookup(curenv->env_pgdir, packet, NULL);
    cbl[current_tcb_num].tbd1.buffer_address = page2pa(packet_page) + sizeof(int);
    cbl[current_tcb_num].tbd1.buffer_size = size;
    // clear the s bit of the previous tcb
    cbl[prev_tcb_num].header.cmd &= ~COMMAND_S;
    uint16_t cu_status = inb(io_base) & 0xc0; // bits 7 and 6 of status
    if (cu_status == 0x00 || cu_status == 0x80) { // idle or suspended
      int tcb_to_send = (current_tcb_num + 1) % CBL_SIZE;
      while (tcb_to_send != current_tcb_num && cbl[tcb_to_send].header.status & STATUS_C) {
	tcb_to_send = (tcb_to_send + 1) % CBL_SIZE;
      }
      start_cu(tcb_to_send);
    } else {
      resume_cu();
    }
    prev_tcb_num = (prev_tcb_num + 1) % CBL_SIZE;
  }
}

int
e100_receive_packet(char *packet, int *size) {
  if (rfa[current_rfd_num].header.status & STATUS_C) {
    *size = rbds[current_rfd_num].count & 0x3fff;
    //memmove(packet, KADDR(rbds[current_rfd_num].buffer_address), *size);
    //struct Page *packet_page = pa2page(rbds[current_rfd_num].buffer_address);
    //page_insert(curenv->env_pgdir, packet_page, packet, PTE_P | PTE_U | PTE_W);
    //packet = KADDR(rbds[current_rfd_num].buffer_address);
    rfa[current_rfd_num].header.status = 0;
    current_rfd_num = (current_rfd_num + 1) % RFA_SIZE;
    return 0;
  }
  return -1;
}

int
e100_map_receive_buffers(char *first_buffer) {
  buffer_zero = first_buffer;
  init_rfa();
  return 0;
}

int
e100_receive_packet_zero_copy(int *size) {
  if (rfa[current_rfd_num].header.status & STATUS_C) {
    *size = rbds[current_rfd_num].count & 0x3fff;
    rfa[current_rfd_num].header.status = 0;
    current_rfd_num = (current_rfd_num + 1) % RFA_SIZE;
    return 0;
  }
  return -1;
}

void
start_cu(int tcb_to_send) {
  if (cu_started) {
    // resume cu
    resume_cu();
  } else {
    // start cu
    outl(io_base + 0x4, PADDR(&cbl[tcb_to_send]));
    outb(io_base + 0x2, 0x10);
    cu_started = 1;
  }
}

void
resume_cu() {
  outb(io_base + 0x2, 0x20);
}

void
start_ru() {
  outl(io_base + 0x4, PADDR(&rfa[current_rfd_num]));
  outb(io_base + 0x2, 0x01);
}

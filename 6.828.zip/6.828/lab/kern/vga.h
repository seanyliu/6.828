/*
This code is a JOS implementation of http://wiki.osdev.org/Bochs_VBE_extensions
*/

#define VBE_DISPI_IOPORT_INDEX  0x01CE
#define VBE_DISPI_IOPORT_DATA   0x01CF

#define VBE_DISPI_INDEX_ID      0
#define VBE_DISPI_INDEX_XRES    1
#define VBE_DISPI_INDEX_YRES    2
#define VBE_DISPI_INDEX_BPP     3
#define VBE_DISPI_INDEX_ENABLE  4

#define VBE_DISPI_DISABLED      0
#define VBE_DISPI_ENABLED       1

#define VBE_DISPI_LFB_ENABLED   0x40
#define VBE_DISPI_NOCLEARMEM    0x80

#define VBE_DISPI_MAX_XRES      1024
#define VBE_DISPI_MAX_YRES      768

#define VBE_DISPI_BPP_32        0x20

#define VBE_DISPI_ID4           0xB0C4

#define VBE_DISPI_LFB_PHYSADDR  0xE0000000
#define VBE_DISPI_LFB_VADDR     0xFFC00000 // arbitrary, but fits a frame buffer up to 4GB

#define FONT_WIDTH              8
#define FONT_HEIGHT             16

#define	PTE_SHARE	0x400

extern uint8_t _binary_obj_fs_font_start[];

void vga_init(void);
void vga_putc(int c);
void vga_map_framebuffer(void);
void vga_draw_buffer(int x, int y, int width, int height, uint32_t *buffer_addr);
void set_pixel(uint32_t x, uint32_t y, uint32_t color);
uint32_t vga_get_height(void);
uint32_t vga_get_width(void);

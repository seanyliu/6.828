#ifndef JOS_KERN_WMGR_H
#define JOS_KERN_WMGR_H
#include <inc/types.h> // need for uint32_t, etc.
#include <kern/env.h> // need for envid_t
#include <kern/pmap.h>

#define TITLE_BAR_HEIGHT 20
#define BORDER_WIDTH 3
#define BORDER_COLOR 0xC8C8C8
#define CLOSE_BOX_COLOR 0x660000

#define MAX_WINDOWS 16

#define BLACK 0x000000
#define WHITE 0xFFFFFF

#define MOUSE_SIZE 15

extern uint8_t _binary_obj_fs_starcraft_start[];
extern uint8_t _binary_obj_fs_bebop_start[];
extern uint8_t _binary_obj_fs_win7_start[];

struct window {
  uint32_t x;
  uint32_t y;
  uint32_t frame_buffer_address; // user virtual address
  uint32_t width;
  uint32_t height;
};

struct window_node {
  envid_t envid;
  struct window_node *next;
  struct window_node *prev;
  struct window window;
};

void wmgr_init(void);
int open_window(int envid, int width, int height, uint32_t *buf);
int close_window(int envid);
int update_window(int envid);
void mouse_update(int x, int y, int left_pressed, int right_pressed, int middle_pressed);
void set_bg(int bgselect);

#endif // !JOS_KERN_WMGR_H

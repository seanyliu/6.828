#ifndef JOS_INC_STDIO_H
#define JOS_INC_STDIO_H

#include <inc/stdarg.h>
#include <inc/types.h>

#ifndef NULL
#define NULL	((void *) 0)
#endif /* !NULL */

// lib/printf.c
void vga_putchar(int c);

// lib/stdio.c
void	cputchar(int c);
int	getchar(void);
int	iscons(int fd);

// lib/printfmt.c
void	printfmt(void (*putch)(int, void*), void *putdat, const char *fmt, ...);
void	vprintfmt(void (*putch)(int, void*), void *putdat, const char *fmt, va_list);
int	snprintf(char *str, int size, const char *fmt, ...);
int	vsnprintf(char *str, int size, const char *fmt, va_list);

// lib/printf.c
int	cprintf(const char *fmt, ...);
int	vcprintf(const char *fmt, va_list);

// lib/fprintf.c
int	printf(const char *fmt, ...);
int	fprintf(int fd, const char *fmt, ...);
int	vfprintf(int fd, const char *fmt, va_list);

// lib/readline.c
char*	readline(const char *prompt);

// lib/window_buffer.c
// these functions are needed to print fonts to vga
int     window_set_pixel(uint32_t x, uint32_t y, uint32_t color);
int     init_window_buffer(int width, int height);
uint32_t* get_window_buffer(void);
int     is_window_buffer_initialized(void);
int     get_window_height(void);
int     get_window_width(void);
char*  get_font_buffer(void);

#endif /* !JOS_INC_STDIO_H */

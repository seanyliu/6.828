// Implementation of cprintf console output for user environments,
// based on printfmt() and the sys_cputs() system call.
//
// cprintf is a debugging statement, not a generic output statement.
// It is very important that it always go to the console, especially when 
// debugging file descriptor code!

#include <inc/types.h>
#include <inc/stdio.h>
#include <inc/stdarg.h>
#include <inc/lib.h>

// =======================
// VGA font printing
#define VGA_FONT
#define FONT_WIDTH              8
#define FONT_HEIGHT             16
static int font_color = 0xFFFFFF;
static int vga_char_pos = 0;

int char_printed = 0;

void vga_putchar(int c) {
  int font_max_cols;
  int font_max_rows;
  int font_max_chars;
  int fontidx;
  char fontbyte;
  static char *font_buffer;
  int rowidx;
  int colidx;
  int fontnum;
  int color;
  int vga_bg = 0x000000;
  uint32_t* frame_buffer;

  if (is_window_buffer_initialized() == 0) return;

  font_max_cols = get_window_width() / FONT_WIDTH;
  font_max_rows = get_window_height() / FONT_HEIGHT;
  font_max_chars = font_max_cols * font_max_rows;
  font_buffer = get_font_buffer();
  frame_buffer = get_window_buffer();

  // ========================
  // Step 1: calculate the index of the character, should just be c - 32
  // if no attribute given, then use space

  switch (c & 0xff) {
    case '\n':
      vga_char_pos += font_max_cols - (vga_char_pos % font_max_cols);
      break;
    case '\r':
    case '\t':
      break;
    case '\b':
      vga_char_pos--;
      break;
  }
  fontidx = c - 32;

  if ((c > 126) || (c < 32)) {
    fontidx = 0;
  }
  // ========================
  // Step 2: Draw the character
  for (rowidx = 0; rowidx < FONT_HEIGHT; rowidx++) {
    // read out one row of font
    fontnum = (fontidx * 16) + rowidx;
    fontbyte = font_buffer[fontnum];
    for (colidx = 0; colidx < FONT_WIDTH; colidx++) {
      if ((fontbyte & (0x80 >> colidx)) != 0) {
        color = font_color;
      } else {
        color = vga_bg;
      }
      window_set_pixel(colidx + ((vga_char_pos % font_max_cols) * FONT_WIDTH), rowidx + ((vga_char_pos / font_max_cols) * FONT_HEIGHT), color);
    }
  }
  if ((c != '\b') && (c != '\n')) vga_char_pos++;


  // =======================
  // Scroll the page
  if (vga_char_pos > (font_max_chars - 1)) {
    // frame_buffer is a uint32_t, therefore * 1
    memmove(frame_buffer, frame_buffer + ((get_window_width() * FONT_HEIGHT)*1), (get_window_width() * get_window_height() - (get_window_width() * FONT_HEIGHT)) * 4);
    for (rowidx = 0; rowidx < FONT_HEIGHT; rowidx++) {
      for (colidx = 0; colidx < get_window_width(); colidx++) {
        window_set_pixel(colidx, get_window_height() - FONT_HEIGHT + rowidx, vga_bg);
      }
    }
    vga_char_pos -= font_max_cols;
  }

}
// =======================


// Collect up to 256 characters into a buffer
// and perform ONE system call to print all of them,
// in order to make the lines output to the console atomic
// and prevent interrupts from causing context switches
// in the middle of a console output line and such.
struct printbuf {
	int idx;	// current buffer index
	int cnt;	// total bytes printed so far
	char buf[256];
};


static void
putch(int ch, struct printbuf *b)
{
        // vga font print
        vga_putchar(ch);

	b->buf[b->idx++] = ch;
	if (b->idx == 256-1) {
		sys_cputs(b->buf, b->idx);
		b->idx = 0;
	}
	b->cnt++;
}

int
vcprintf(const char *fmt, va_list ap)
{
	struct printbuf b;

	b.idx = 0;
	b.cnt = 0;
	vprintfmt((void*)putch, &b, fmt, ap);
	sys_cputs(b.buf, b.idx);

	return b.cnt;
}

int
cprintf(const char *fmt, ...)
{
	va_list ap;
	int cnt;

	va_start(ap, fmt);
	cnt = vcprintf(fmt, ap);
	va_end(ap);

        // print line at a time instead of char at a time
        if (is_window_buffer_initialized() == 1) {
          sys_update_window(sys_getenvid());
        }

	return cnt;
}


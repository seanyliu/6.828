// Ping-pong a counter between two processes.
// Only need to start one of these -- splits into two with fork.

#include <inc/lib.h>

void
umain(void)
{
	envid_t who;

	int yidx;
	int width = 350;
	int height = 200;
	init_window_buffer(width, height);
	sys_open_window(sys_getenvid(), width, height, get_window_buffer());

	if ((who = fork()) != 0) {
		// get the ball rolling
		cprintf("send 0 from %x to %x\n", sys_getenvid(), who);
		ipc_send(who, 0, 0, 0);
	}

	while (1) {
		uint32_t i = ipc_recv(&who, 0, 0);
		cprintf("%x got %d from %x\n", sys_getenvid(), i, who);
		
		if (i == 100)
		  break;
		i++;
		ipc_send(who, i, 0, 0);
		
		if (i == 100)
		  break;
                for (yidx = 0; yidx < 1000; yidx++) {
                  sys_yield();
                }
	}
	sys_close_window(sys_getenvid());	
}


#include <inc/lib.h>

void
umain(int argc, char **argv)
{
	int bg;

	argv0 = "setbg";
	if (argc != 2) {
	  panic("setbg: incorrect number of arguments");
	} else {
	  if (!strncmp(argv[1], "starcraft", 9)) {
	    bg = 0;
	  } else if (!strncmp(argv[1], "bebop", 5)) {
	    bg = 1;
	  } else if (!strncmp(argv[1], "win7", 4)) {
	    bg = 2;
	  } else {
	    bg = -1;
	  }
	  sys_set_bg(bg);
	}
}

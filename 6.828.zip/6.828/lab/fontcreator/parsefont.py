import fileinput
import re
import math
import random

# ====================
# Inputs
# Font file downloaded from: 
# http://linux.softpedia.com/get/Desktop-Environment/Fonts/intlfonts-35037.shtml
fontFile = "cyr16-etl.bdf"

# Outputs
outputFile = "font.josfont"
#hexdump font.josfont -C

# ======================
# Extract the sentences
sentences = []
for line in fileinput.input([fontFile]):
  line = line.lower()
  line = line.strip()
  if line == "":
    continue
  if "\t" in line:
    line = line.split("\t")[1]
  line = re.sub("\.", "", line)
  line = re.sub("\?", "", line)
  line = re.sub("\,", "", line)
  line = re.sub("\-", "", line)
  line = re.sub(" +", " ", line)
  sentences.append(line)

file = open(outputFile,"wb")

# ======================
# Write all the characters to a font file
sidx = 0
while sidx < len(sentences):
  line = sentences[sidx]
  if line == "bitmap":
    print "---"
    for cidx in range(16):
      characters = sentences[sidx + cidx + 1]
      print "%x" % int(characters, 16)
      file.write(chr(int(characters, 16)))
    sidx = sidx + 16
  sidx = sidx + 1

file.close()

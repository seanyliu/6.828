#include "ns.h"

#define PKTMAP		0x10000000

void
output(envid_t ns_envid)
{
	binaryname = "ns_output";
	// LAB 6: Your code here:
	// 	- read a packet from the network server
	//	- send the packet to the device driver
	envid_t from_envid;
	struct jif_pkt* packet = (struct jif_pkt*) PKTMAP;
	while(1) {
	  if (ipc_recv(&from_envid, packet, NULL) != NSREQ_OUTPUT) {
	    continue;
	  }
	  if (from_envid == ns_envid) {
	    // send the packet
	    sys_send_packet(packet->jp_data, packet->jp_len);
	  }
	}
}
